# Deploying Skinify to Cloudflare Pages (no `wrangler` CLI install required)

This guide walks you through deploying Skinify to Cloudflare Pages using the **dashboard Git integration** — meaning you connect a GitHub/GitLab repo in the Cloudflare web UI, and Cloudflare builds & deploys automatically on every push.

You do **not** need to install `wrangler` on your machine. The `wrangler.jsonc` file in the project root is just a config file consumed by Cloudflare's build system — it does not require the CLI.

---

## TL;DR — what works out of the box

| Feature | Cloudflare Pages | Notes |
| --- | --- | --- |
| Marketing pages, dashboard UI, scanning UI | ✅ Works | Static + edge-rendered React, no Node APIs needed. |
| Auth, sessions, dashboard data | ✅ Works | Postgres via Hyperdrive (see "Database" below). |
| AR engine (MediaPipe + Three.js) | ✅ Works | All client-side — runs in the browser, never on the worker. |
| `model-viewer` "View in your space" | ✅ Works | Loads from unpkg CDN — already added to CSP. |
| Scan-to-3D pipeline | ✅ Works | Uses R2 for storage (instead of Vercel Blob). |
| GLB processing (`@gltf-transform`) | ⚠️ Needs verification | Pure JS but uses Node Buffer. With `nodejs_compat` it should work; if it fails, move to a separate Worker. |
| Mock reconstruction provider | ⚠️ Reads seed GLBs from `public/seed/` at runtime | Works — those files are served statically. |
| Stripe billing | ✅ Works | HTTPS webhook endpoint. |

---

## Step 1 — Push the project to GitHub

1. Unzip `skinify-cloudflare.zip` locally.
2. `cd skinnex-main && git init && git add -A && git commit -m "Skinify with Cloudflare Pages config"`
3. Create a private GitHub repo and push: `git remote add origin git@github.com:you/skinify.git && git push -u origin main`

You can keep the repo private — Cloudflare Pages supports private repos.

---

## Step 2 — Provision Cloudflare resources

In the Cloudflare dashboard:

1. **Pages** → Create a project → Connect to Git → pick your Skinify repo.
2. **R2** → Create bucket (e.g. `skinify-assets`) → Settings → Public access → connect a custom domain or use the default `*.r2.dev` URL. Note the **public URL**.
3. **R2** → Manage R2 API Tokens → Create API token with **Object Read & Write** permission for your bucket. Note `Access Key ID`, `Secret Access Key`, and `Account ID` (visible on the R2 dashboard).
4. **Hyperdrive** (only if you're using a TCP Postgres like Neon/Supabase/RDS) → Create configuration → paste your Postgres connection string. Cloudflare will give you a Hyperdrive connection string that looks like `postgres://user:pass@hyperdrive-host:5432/db`. Use that as `DATABASE_URL`.

If you don't need server-side features (uploads, GLB processing, scan-to-3D), you can skip R2 and Hyperdrive and deploy Skinify as a static demo — but most dashboard features will throw 503s.

---

## Step 3 — Configure the Cloudflare Pages build

In the Pages project settings:

- **Framework preset**: `Next.js`
- **Build command**: `npm run pages:build`
- **Build output directory**: `.open-next/assets`
- **Root directory**: `/` (leave blank)
- **Node version**: `20` (Settings → Environment variables → add `NODE_VERSION=20`)

This runs `@opennextjs/cloudflare` (already in `devDependencies`), which converts the Next.js build output to a Cloudflare Workers-compatible bundle. The `npx --yes` in the script means Cloudflare's build runner downloads the adapter on demand — no global install needed.

> **Note on adapters**: this project uses `@opennextjs/cloudflare` (the newer officially-supported adapter) instead of `@cloudflare/next-on-pages`, because the latter only supports Next.js ≤15.5.2 and Skinify uses Next.js 15.5.26+. OpenNext is the recommended path for Next.js 15.5+ on Cloudflare Workers.

---

## Step 4 — Set environment variables

In Cloudflare Pages → Settings → Environment variables (Production), add:

| Variable | Required | Example |
| --- | --- | --- |
| `DATABASE_URL` | ✅ | Neon pooled Postgres URL **or** Hyperdrive connection string |
| `NEXT_PUBLIC_SITE_URL` | ✅ | `https://skinify.pages.dev` (your Pages domain) |
| `R2_ACCOUNT_ID` | if using R2 | `abcd1234…` (from R2 dashboard) |
| `R2_BUCKET` | if using R2 | `skinify-assets` |
| `R2_ACCESS_KEY_ID` | if using R2 | `abcdef…` |
| `R2_SECRET_ACCESS_KEY` | if using R2 | `…` (long secret) |
| `NEXT_PUBLIC_R2_PUBLIC_URL` | if using R2 | `https://cdn.example.com` |
| `RECONSTRUCTION_PROVIDER` | no | `mock` (default — prototype) |
| `RECONSTRUCTION_API_KEY` | if provider ≠ mock | server-side secret |
| `STRIPE_SECRET_KEY` | optional | for card payments |
| `STRIPE_WEBHOOK_SECRET` | optional | for card payments |

Cloudflare's build system sets `CF_PAGES=1` and `CF_PAGES_COMMIT_SHA=…` automatically — Skinify uses these to detect the Cloudflare environment.

---

## Step 5 — Enable `nodejs_compat`

The `wrangler.jsonc` in this repo already sets `"compatibility_flags": ["nodejs_compat"]` — but if Cloudflare Pages Git integration doesn't pick it up automatically, set the flag manually:

- Cloudflare Pages → Settings → Functions → Compatibility flags
- Add `nodejs_compat` to "Production" and "Preview"

This is what lets the GLB-processing libraries (`@gltf-transform`, `meshoptimizer`) run on Cloudflare's edge runtime.

---

## Step 6 — Trigger the first build

In Cloudflare Pages → Deployments → **Retry deployment** (or push an empty commit to your repo: `git commit --allow-empty -m "trigger deploy" && git push`).

The first build takes ~3–5 minutes. Cloudflare installs dependencies (`npm ci`), runs `npm run pages:build`, and ships the static + edge-function bundle to your `*.pages.dev` domain.

---

## Step 7 — Run database migrations (one-time)

Cloudflare Pages can't run migrations from inside the worker. From your local machine:

```bash
DATABASE_URL='postgres://…your-neon-or-supabase-url…' npm run db:migrate
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-strong-one' DEMO_SELLER_PASSWORD='another-one' npm run db:seed
```

You only need to do this once. The worker reads from the same database.

---

## What's different from the Vercel deployment

| Concern | Vercel | Cloudflare Pages |
| --- | --- | --- |
| Build command | `npm run build` | `npm run pages:build` |
| Build output | `.next/` (managed by Vercel) | `.open-next/` (managed by OpenNext adapter) |
| Object storage | Vercel Blob | Cloudflare R2 (S3-compatible API) |
| DB connection | Direct TCP to Postgres | Hyperdrive proxy (Workers can't open raw TCP) |
| Edge functions | Vercel Edge runtime | Cloudflare Workers runtime (with `nodejs_compat`) |
| Environment vars | Dashboard or `.env.local` | Dashboard only (no `.env.local` in production) |
| Custom domains | Vercel settings | Cloudflare DNS + Pages custom domain |

---

## Local testing of the Cloudflare build

If you want to verify the Cloudflare build works locally before pushing:

```bash
npm install
npm run pages:build     # produces .open-next/ directory
# Optional — preview with wrangler (one-time install via npx):
npx wrangler@latest dev .open-next/worker.js --assets .open-next/assets --compatibility-flag=nodejs_compat
```

The `npx wrangler` invocation downloads wrangler on demand — it's not installed globally, and you don't need it for production deployment via Git integration.

---

## Troubleshooting

### "R2 storage requires @aws-sdk/signature-v4 + @aws-sdk/protocol-http + @aws-crypto/sha256-js"

Run once locally and commit `package.json` + `package-lock.json`:

```bash
npm install @aws-sdk/signature-v4 @aws-sdk/protocol-http @aws-crypto/sha256-js
```

These packages add ~150 KB to `node_modules` and let `lib/server/storage.ts` sign R2 PUT requests.

### "DATABASE_URL is not configured"

You didn't set the env var in the Cloudflare Pages dashboard. Add it under Settings → Environment variables (Production) and trigger a new deployment.

### Postgres connection works on Vercel but not Cloudflare

Cloudflare Workers/Pages can't open raw TCP sockets. You must use Hyperdrive (which proxies Postgres over the Cloudflare network) — set `DATABASE_URL` to the Hyperdrive connection string, not the raw Neon/Supabase URL.

### GLB upload fails with 422 "Invalid 3D model"

The `@gltf-transform` package uses `Buffer` and `crypto` Node APIs. With `nodejs_compat` enabled they should work, but if you see errors:
- Verify `nodejs_compat` is set (Settings → Functions → Compatibility flags)
- If still failing, move GLB processing to a separate Cloudflare Worker that has `nodejs_compat_v2` (the v2 flag enables more Node APIs)

### model-viewer 3D viewer doesn't load

Check the browser console — the most common cause is CSP blocking `unpkg.com`. The `next.config.mjs` already allows `https://unpkg.com` in `script-src` and `connect-src`, but if you've overridden the CSP via Cloudflare Pages settings, make sure `unpkg.com` is still in the allow-list.

### AR "View in your space" button doesn't appear

This is by design — Google's `<model-viewer>` automatically hides the AR button on devices that don't support it (desktop, browsers without WebXR / Scene Viewer / Quick Look). On supported Android (Chrome + ARCore) and iOS (Safari + AR Quick Look) it appears normally.

---

## What to do if you want to stay on Vercel

Nothing — the project is still 100% Vercel-compatible. The Cloudflare additions are additive:
- `wrangler.jsonc` — only used by Cloudflare; ignored by Vercel
- `public/_headers`, `public/_routes.json` — only used by Cloudflare Pages
- `package.json` scripts `pages:build`, `pages:dev` — only run when you call them
- `lib/server/storage.ts` R2 branch — only activates when `R2_BUCKET` + `R2_ACCESS_KEY_ID` + `R2_SECRET_ACCESS_KEY` are set; falls back to Vercel Blob otherwise

You can deploy the same codebase to either platform.
