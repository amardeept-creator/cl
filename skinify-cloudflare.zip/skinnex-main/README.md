# SKINIFY — Try it. Before you buy it.

SKINIFY is an AR commerce platform: brands turn products into **Skinners** (browser-based AR try-on experiences) and share them anywhere with a link, QR code or embed; customers discover products and try them on with their camera — no app, no account.

> SKINIFY is **not** a skin-analysis, dermatology or skincare product. It performs no diagnosis or medical analysis of any kind.

## Stack

| Layer | Choice |
| --- | --- |
| App | Next.js 15 (App Router, React 19, TypeScript), deployed on Vercel **or Cloudflare Pages** |
| Database | PostgreSQL (Neon in production; any Postgres locally) via `postgres` driver. On Cloudflare, use Hyperdrive as the connection string. |
| File storage | Vercel Blob (Vercel) **or Cloudflare R2** (S3-compatible API over HTTPS — works on Workers edge runtime). |
| AR tracking | MediaPipe Tasks Vision (hand / face / pose / segmentation), on-device, WebGL/WASM |
| Rendering | Three.js (PBR materials, Draco + Meshopt decoding, depth occluders, camera-based light estimation) |
| 3D pipeline | glTF-Transform + meshoptimizer (validate → inspect → dedup/prune → compress) |
| Billing | Stripe Checkout + signed webhooks (optional — disabled until keys are set) |
| Cloudflare adapter | `@opennextjs/cloudflare` (the officially-supported Next.js-on-Workers adapter for Next 15.5+) — see `CLOUDFLARE_DEPLOYMENT.md` |

## Project layout

```
app/(site)          customer pages: home, explore, categories, brands, product, brand store, saved, pricing, docs
app/s/[slug]        public Skinner link (full-screen AR)      app/embed/[slug]  iframe embed
app/try/[b]/[p]     readable alias → /s/[slug]                 app/(auth)        login / signup
app/onboarding      seller onboarding (brand → first Skinner)  app/dashboard/*   seller studio
app/admin           platform admin                             app/api/*         JSON APIs (+ /api/v1 public API)
lib/ar/*            BODY-PART AR TRACKING ENGINE (config, vision loader, solvers, filters, nails, engine, viewer)
lib/server/*        db, auth, sessions, rate limit, storage, GLB validation, entitlements, links, analytics
db/schema.sql       full schema     scripts/migrate.mjs, scripts/seed.ts
```

## Local development

```bash
npm install
cp .env.example .env.local        # set DATABASE_URL (any Postgres 14+)
npm run db:migrate                # creates tables (idempotent)
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-strong-one' DEMO_SELLER_PASSWORD='another-one' npm run db:seed
npm run dev                       # http://localhost:3000
```

Camera access requires HTTPS or `localhost`. Uploads are stored in `.data/` locally when no Blob token is configured.

## Deploying to Vercel

1. **Database** — create a Neon project (or use Vercel → Storage → Neon). Copy the **pooled** connection string.
2. **Blob** — Vercel → Storage → Create → Blob, connect it to the project (sets `BLOB_READ_WRITE_TOKEN`).
3. **Environment variables** (Project → Settings → Environment Variables):
   - `DATABASE_URL` (required) · `NEXT_PUBLIC_SITE_URL` (required, e.g. `https://skinify.vercel.app`)
   - `BLOB_READ_WRITE_TOKEN` (required for seller uploads)
   - `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` (optional; set a `stripe_price_id` per plan in Admin → Plans)
4. **Migrate + seed** once from your machine against the production database:
   ```bash
   DATABASE_URL='postgres://…pooler…/neondb?sslmode=require' npm run db:migrate
   DATABASE_URL='…' ADMIN_EMAIL=… ADMIN_PASSWORD=… DEMO_SELLER_PASSWORD=… npm run db:seed   # SEED_DEMO=false to skip demo brands
   ```
5. **Deploy** — `vercel deploy --prod` (or push to the connected Git repo). Build command `npm run build`, output is the Next.js default, Node 20+.
6. Stripe webhook endpoint: `https://<domain>/api/billing/webhook` with events `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`. Only a signature-verified webhook activates a paid plan.

### Production notes

- Rate limiting is in-memory per serverless instance (good against bursts, not a global quota). For strict global limits, swap `lib/server/ratelimit.ts` for Upstash Redis.
- MediaPipe WASM is copied to `/public/mediapipe` at build time; task models load from Google's CDN by default (override with `NEXT_PUBLIC_MP_*`).
- Camera frames never leave the device. Photos/videos are only saved when the customer taps save/share, and are never uploaded to SKINIFY.

## Feature status (honest)

See the in-app `/how-it-works` page and the final build report. Summary:

- **Fully functional:** discovery/search/filters, product & brand pages, favourites (local), live AR for rings, watches, bracelets, glasses, earrings, lipstick, nails, hats, necklaces, bags, surface placement; photo/video capture and native share; seller signup, brands, 7-step Skinner wizard, GLB upload/validation/optimisation, live preview, publish/unpublish/duplicate/delete, links, QR (SVG/PNG/print), iframe embed + SDK button, real analytics, configurable plans and limits, expiry handling, admin moderation, API keys + `/api/v1`.
- **Scan-to-3D pipeline (new):** full-screen scanning UI (`/dashboard/skinners/[id]/view` + wizard integration), coverage tracking (6 cardinal bins), smart keyframe selection (sharpness + brightness + motion), frame upload, server-side reconstruction provider abstraction with a clearly-labelled mock provider, processing overlay, and Google `<model-viewer>` "View in your space" experience.
- **Requires external service:** online card payments (Stripe keys), seller uploads on Vercel (Blob token), real photogrammetry (set `RECONSTRUCTION_PROVIDER` to a non-`mock` value once a real provider is implemented in `lib/server/reconstruction/`).
- **Experimental:** 2D garment overlay on body (segmentation-based, not a true cloth simulation), shoes (pose-based ankle anchoring, low precision).

## Scan-to-3D pipeline

```
CREATE SKINNER → wizard step "3D / AR asset" → "Scan a physical product"
   ↓
ScanCapture.tsx (camera + coverage UI)
   ↓
/api/scan/session      → creates scan_sessions row
/api/scan/upload       → uploads JPEG keyframes (server-side validated)
/api/scan/reconstruct  → finalize coverage + start reconstruction_jobs row
   ↓
lib/server/reconstruction/{mock,types,index}.ts → provider.submit → provider.poll
   ↓
processGlb() — server-side GLB validation + dedup/prune/meshopt
   ↓
ar_assets row (the optimized AR-ready GLB)
   ↓
ModelViewer3D.tsx — Google <model-viewer> with AR button (Scene Viewer / Quick Look)
   ↓
"View in your space" on Android/iOS / interactive 3D viewer on desktop
```

### Reconstruction providers

The provider abstraction is at `lib/server/reconstruction/`. The active provider is selected by `RECONSTRUCTION_PROVIDER` env var (default `mock`).

| Provider value | File | Status |
| --- | --- | --- |
| `mock` (default) | `mock.ts` | Implemented — **prototype**. Picks an existing SKINIFY seed GLB based on category and runs it through the standard GLB pipeline so the result is a real, AR-ready GLB. Results are clearly labelled as prototype to the seller. |
| `tripo3d` | `tripo3d.ts` | **Stub** — uncomment + implement when you have an API key. |
| `luma` | `luma.ts` | **Stub** — uncomment + implement when you have an API key. |
| `meshy` | `meshy.ts` | **Stub** — uncomment + implement when you have an API key. |
| `nvidia_omniverse` | `nvidia_omniverse.ts` | **Stub** — uncomment + implement when you have an API key. |
| `custom` | `custom.ts` | **Stub** — for in-house / self-hosted photogrammetry. |

Each provider implements `ReconstructionProvider` from `types.ts`. Secrets (`RECONSTRUCTION_API_KEY`, `RECONSTRUCTION_API_URL`) are read at call-time, never at import time, and never exposed to the browser.

### New environment variables

| Variable | Required | Default | Purpose |
| --- | --- | --- | --- |
| `RECONSTRUCTION_PROVIDER` | no | `mock` | Active reconstruction provider. |
| `RECONSTRUCTION_API_KEY` | only when provider ≠ `mock` | — | Server-side API key for the provider. Never exposed to the browser. |
| `RECONSTRUCTION_API_URL` | no | provider default | Override the provider's API base URL (useful for self-hosted photogrammetry). |

No new database secrets — scan frames and reconstructed GLBs are stored using the existing Vercel Blob driver.

### Cost control

The scan pipeline is deliberately cheap to operate:

- Client-side keyframe selection (sharpness + brightness + motion + 25° viewpoint delta). Most captured frames are discarded before upload.
- Hard cap of 12 keyframes per session uploaded (configurable in `lib/client/scan/coverage.ts`).
- Hard cap of 240 frames per session + 4 MB per frame (server-enforced in `lib/server/reconstruction/pipeline.ts`).
- Server-side `processGlb()` runs the standard glTF-Transform dedup/prune/meshopt pipeline so the resulting GLB is already optimized for mobile AR.
- Providers are polled, not streamed — no long-lived connections.
- The mock provider is free (uses existing seed models). Real providers cost money only when a seller actually finishes a scan.

### New database tables (additive, idempotent)

- `scan_sessions` — scan coverage + status.
- `scan_frames` — every uploaded frame, with viewpoint metadata and `is_keyframe` flag.
- `reconstruction_jobs` — provider job state, links a scan_session → ar_asset.

Run `npm run db:migrate` (idempotent) — existing tables are untouched.

### Product-specific AR modes (future)

`scan_sessions.category_slug` lets the pipeline know what kind of product was scanned, which means future versions can route to specialised body-part AR (jewellery → wrist/finger, shoes → feet, glasses → face, etc.). For the first implementation, all scanned products land on `surface_place` (generic "place in your room" mode). The architecture supports adding specialised modes without rebuilding the product system.
