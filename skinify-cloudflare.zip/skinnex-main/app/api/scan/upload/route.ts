import { z } from 'zod';
import { json, handle, assertSameOrigin, HttpError } from '@/lib/server/http';
import { requireSeller } from '@/lib/server/auth';
import { storeScanFrame, MAX_FRAMES_PER_SESSION } from '@/lib/server/reconstruction/pipeline';
import { rateLimit } from '@/lib/server/ratelimit';

/** Direct multipart frame upload. Each frame is a single JPEG captured by the client.
 *  Frames larger than 4 MB must be re-captured by the client (downscaled) before upload. */
export const runtime = 'nodejs';
export const maxDuration = 30;

const VIEWPOINT = z.object({
  yawDeg: z.number().min(-360).max(360),
  pitchDeg: z.number().min(-180).max(180),
  sharpness: z.number().min(0).max(1).optional(),
  brightness: z.number().min(0).max(1).optional(),
  trackerConfidence: z.number().min(0).max(1).optional(),
});

export const POST = handle(async (req: Request) => {
  assertSameOrigin(req);
  const u = await requireSeller();
  if (!rateLimit('scan:' + u.sellerId, 120, 60_000).ok) throw new HttpError(429, 'Too many frames. Slow down a little.');

  const form = await req.formData();
  const sessionId = String(form.get('sessionId') || '');
  if (!sessionId) throw new HttpError(400, 'sessionId required');
  const seqRaw = Number(form.get('sequence') || -1);
  if (!Number.isInteger(seqRaw) || seqRaw < 0 || seqRaw > MAX_FRAMES_PER_SESSION) throw new HttpError(400, 'Bad sequence');
  const isKey = String(form.get('isKeyframe') || '0') === '1';
  const vpRaw = String(form.get('viewpoint') || '{}');
  let viewpoint: z.infer<typeof VIEWPOINT>;
  try { viewpoint = VIEWPOINT.parse(JSON.parse(vpRaw)); } catch { throw new HttpError(400, 'Bad viewpoint'); }

  const file = form.get('file');
  if (!(file instanceof File)) throw new HttpError(400, 'No frame file');
  if (file.type && !/image\/(jpeg|png|webp)/.test(file.type)) throw new HttpError(415, 'Frames must be JPEG, PNG, or WebP.');

  const buf = new Uint8Array(await file.arrayBuffer());
  const frame = await storeScanFrame(u.sellerId, sessionId, { sequence: seqRaw, bytes: buf, viewpoint, isKeyframe: isKey });
  return json({ frame }, 201);
});
