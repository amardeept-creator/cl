'use client';

/**
 * Coverage tracking + smart keyframe selection for the Skinify scan capture flow.
 *
 * Pure client-side. No frame is uploaded until `pickKeyframes()` decides which
 * ones actually contribute to coverage — this keeps cloud upload volume low and
 * makes the cost story honest.
 *
 * Approach:
 *  - Camera direction is computed from `DeviceOrientationEvent` (alpha = yaw,
 *    beta = pitch). On iOS this requires a one-time permission prompt.
 *  - The unit sphere around the product is divided into 6 named bins:
 *      front, back, left, right, top, bottom
 *    Each bin covers a 90°×90° solid angle centred on its cardinal direction.
 *  - A frame is accepted as a "keyframe" only when it lands in an empty bin OR
 *    meaningfully differs from the nearest already-captured keyframe (viewpoint
 *    delta > 25°). Otherwise the frame is discarded (still counted in
 *    `frame_count` for diagnostics).
 *  - Coverage % = (captured bins / 6) × 60 + (keyframe count up to 12 / 12) × 40
 *    This is deliberately honest: 100% means "we have keyframes from all 6 sides".
 *  - Sharpness / brightness / motion blur are estimated from the frame's pixel
 *    variance and per-frame delta. Low values emit warnings.
 */

export type CoverageBin = 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom';
export const COVERAGE_BINS: CoverageBin[] = ['front', 'back', 'left', 'right', 'top', 'bottom'];

export interface FrameMeta {
  sequence: number;
  yawDeg: number;          // camera yaw around product (deg)
  pitchDeg: number;        // camera pitch (deg)
  sharpness: number;       // 0..1 (1 = sharp, 0 = blurry)
  brightness: number;      // 0..1 (1 = properly exposed)
  motionScore: number;     // 0..1 (1 = stationary, 0 = high motion)
  bin: CoverageBin | null;
  capturedAt: number;       // performance.now()
}

export interface CoverageState {
  bins: Record<CoverageBin, boolean>;
  keyframes: FrameMeta[];      // accepted keyframes (max 12 per session for cost control)
  frameCount: number;          // total captured (incl. rejected)
  selectedFrames: number;      // alias of keyframes.length, exposed for the server contract
  coveragePct: number;         // 0..100, honest
  scanQuality: 'unknown' | 'low' | 'medium' | 'high';
  warnings: ScanWarning[];
  lastBin: CoverageBin | null;
  lastBinChangeAt: number;
  /** Histogram of yaw (12 buckets over 360°). Used by the UI coverage map. */
  yawHistogram: number[];
  /** Histogram of pitch (6 buckets over 180°). */
  pitchHistogram: number[];
}

export type ScanWarning =
  | { kind: 'lighting_low'; msg: string }
  | { kind: 'lighting_high'; msg: string }
  | { kind: 'motion_blur'; msg: string }
  | { kind: 'too_close'; msg: string }
  | { kind: 'too_far'; msg: string }
  | { kind: 'low_sharpness'; msg: string };

export const MAX_KEYFRAMES = 12;

export function makeCoverageState(): CoverageState {
  const bins = { front: false, back: false, left: false, right: false, top: false, bottom: false } as Record<CoverageBin, boolean>;
  return {
    bins,
    keyframes: [],
    frameCount: 0,
    selectedFrames: 0,
    coveragePct: 0,
    scanQuality: 'unknown',
    warnings: [],
    lastBin: null,
    lastBinChangeAt: 0,
    yawHistogram: new Array(12).fill(0),
    pitchHistogram: new Array(6).fill(0),
  };
}

/** Maps (yaw, pitch) → cardinal bin. Yaw 0° = front of product. */
export function binForViewpoint(yawDeg: number, pitchDeg: number): CoverageBin | null {
  // Normalize yaw to -180..180
  let yaw = ((yawDeg + 180) % 360 + 360) % 360 - 180;
  const pitch = Math.max(-90, Math.min(90, pitchDeg));

  // Strong vertical tilt overrides horizontal bin (top/bottom takes priority).
  if (pitch > 50) return 'top';
  if (pitch < -50) return 'bottom';

  if (yaw >= -45 && yaw < 45) return 'front';
  if (yaw >= 45 && yaw < 135) return 'right';
  if (yaw >= -135 && yaw < -45) return 'left';
  return 'back';
}

/** Quick "is this viewpoint meaningfully different from existing keyframes?" check.
 *  Returns true when no existing keyframe is within 25° of (yaw, pitch). */
export function isNovelViewpoint(state: CoverageState, yawDeg: number, pitchDeg: number): boolean {
  for (const k of state.keyframes) {
    const dy = Math.min(Math.abs(yawDeg - k.yawDeg), 360 - Math.abs(yawDeg - k.yawDeg));
    const dp = Math.abs(pitchDeg - k.pitchDeg);
    if (Math.sqrt(dy * dy + dp * dp) < 25) return false;
  }
  return true;
}

export function computeCoveragePct(state: CoverageState): number {
  const filledBins = COVERAGE_BINS.filter(b => state.bins[b]).length;
  const binScore = (filledBins / COVERAGE_BINS.length) * 60;     // 0..60
  const keyframeScore = Math.min(state.keyframes.length, MAX_KEYFRAMES) / MAX_KEYFRAMES * 40; // 0..40
  return Math.round(binScore + keyframeScore);
}

export function deriveScanQuality(state: CoverageState): CoverageState['scanQuality'] {
  if (state.keyframes.length < 3) return 'unknown';
  const avgSharpness = state.keyframes.reduce((s, f) => s + f.sharpness, 0) / state.keyframes.length;
  const filledBins = COVERAGE_BINS.filter(b => state.bins[b]).length;
  if (avgSharpness > 0.6 && filledBins >= 5 && state.warnings.length === 0) return 'high';
  if (avgSharpness > 0.4 && filledBins >= 4 && state.warnings.length <= 2) return 'medium';
  return 'low';
}

/** Appends a captured frame's metadata. Mutates a copy and returns it (React-friendly). */
export function recordFrame(prev: CoverageState, meta: Omit<FrameMeta, 'sequence' | 'bin' | 'capturedAt'> & { sequence?: number }): CoverageState {
  const seq = meta.sequence ?? prev.frameCount;
  const bin = binForViewpoint(meta.yawDeg, meta.pitchDeg);
  const frame: FrameMeta = { ...meta, sequence: seq, bin, capturedAt: performance.now() };

  const next: CoverageState = {
    ...prev,
    bins: { ...prev.bins },
    keyframes: prev.keyframes.slice(),
    warnings: prev.warnings.slice(),
    yawHistogram: prev.yawHistogram.slice(),
    pitchHistogram: prev.pitchHistogram.slice(),
    frameCount: prev.frameCount + 1,
    lastBin: bin,
    lastBinChangeAt: bin !== prev.lastBin ? performance.now() : prev.lastBinChangeAt,
  };

  if (bin) {
    next.bins[bin] = true;
    const yawBucket = Math.floor((((meta.yawDeg % 360) + 360) % 360) / 30) % 12;
    const pitchBucket = Math.max(0, Math.min(5, Math.floor((meta.pitchDeg + 90) / 30)));
    next.yawHistogram[yawBucket]++;
    next.pitchHistogram[pitchBucket]++;
  }

  // Accept as keyframe?
  if (bin && next.keyframes.length < MAX_KEYFRAMES) {
    if (isNovelViewpoint(prev, meta.yawDeg, meta.pitchDeg) && meta.sharpness > 0.35 && meta.motionScore > 0.5) {
      next.keyframes.push(frame);
    }
  }

  // Update warnings (keep most recent 4 of each kind).
  const newWarnings: ScanWarning[] = [];
  if (meta.brightness < 0.18) newWarnings.push({ kind: 'lighting_low', msg: 'Lighting is too dark — move to a brighter spot' });
  else if (meta.brightness > 0.95) newWarnings.push({ kind: 'lighting_high', msg: 'Lighting is too bright — avoid direct sun' });
  if (meta.motionScore < 0.4) newWarnings.push({ kind: 'motion_blur', msg: 'Hold the phone steady' });
  if (meta.sharpness < 0.3) newWarnings.push({ kind: 'low_sharpness', msg: 'Frame is blurry — clean the lens or steady your hand' });

  if (newWarnings.length) {
    // Keep only the most recent unique-by-kind warning set.
    const seen = new Set(newWarnings.map(w => w.kind));
    next.warnings = [...newWarnings, ...prev.warnings.filter(w => !seen.has(w.kind))].slice(0, 4);
  }

  next.selectedFrames = next.keyframes.length;
  next.coveragePct = computeCoveragePct(next);
  next.scanQuality = deriveScanQuality(next);
  return next;
}

/** Returns the dynamic guidance message shown to the user. */
export function guidanceMessage(state: CoverageState): { primary: string; hint?: string } {
  const pct = state.coveragePct;
  if (pct < 20) return { primary: 'Start moving around the product', hint: 'Point the camera at the front of the product, then circle it slowly' };
  if (pct < 50) return { primary: 'Keep rotating — more sides needed', hint: 'Try to capture the back, left and right of the product' };
  if (pct < 80) return { primary: 'Good coverage — capture the remaining side', hint: `Missing: ${missingSides(state).join(', ') || 'a few more angles'}` };
  if (pct < 95) return { primary: 'Almost complete — capture the top or back', hint: 'Tilt the phone up or down to capture the top and bottom' };
  return { primary: 'Full scan captured', hint: 'You can complete the scan now' };
}

export function missingSides(state: CoverageState): CoverageBin[] {
  return COVERAGE_BINS.filter(b => !state.bins[b]);
}

/* ---------- Cheap image-quality estimators ---------- */

/** Estimates sharpness (0..1) using a 64×64 luminance Laplacian variance. */
export function estimateSharpness(ctx: CanvasRenderingContext2D, w: number, h: number): number {
  // Downsample to 64×64 for speed and to suppress sensor noise.
  const sw = 64, sh = 64;
  try {
    ctx.drawImage(ctx.canvas, 0, 0, w, h, 0, 0, sw, sh);
  } catch { return 0.5; }
  const { data } = ctx.getImageData(0, 0, sw, sh);
  const lum = new Float32Array(sw * sh);
  for (let i = 0; i < sw * sh; i++) {
    lum[i] = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
  }
  // Laplacian kernel: 0 -1 0 / -1 4 -1 / 0 -1 0 → variance of the response.
  let sum = 0, sumSq = 0, n = 0;
  for (let y = 1; y < sh - 1; y++) {
    for (let x = 1; x < sw - 1; x++) {
      const i = y * sw + x;
      const v = 4 * lum[i] - lum[i - 1] - lum[i + 1] - lum[i - sw] - lum[i + sw];
      sum += v; sumSq += v * v; n++;
    }
  }
  const mean = sum / n;
  const variance = Math.max(0, sumSq / n - mean * mean);
  // Empirical normalization: variances of ~500+ typically indicate a sharp frame.
  return Math.min(1, variance / 500);
}

/** Estimates brightness (0..1) from the average luminance of a 64×64 downsample. */
export function estimateBrightness(ctx: CanvasRenderingContext2D, w: number, h: number): number {
  const sw = 32, sh = 32;
  try { ctx.drawImage(ctx.canvas, 0, 0, w, h, 0, 0, sw, sh); } catch { return 0.5; }
  const { data } = ctx.getImageData(0, 0, sw, sh);
  let sum = 0;
  for (let i = 0; i < sw * sh; i++) {
    sum += 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
  }
  return Math.min(1, sum / (sw * sh) / 255);
}

/** Estimates motion (0..1, where 1 = stationary) by comparing two consecutive frames. */
export function estimateMotion(prev: ImageData | null, ctx: CanvasRenderingContext2D, w: number, h: number): { motion: number; frame: ImageData } {
  const sw = 32, sh = 32;
  try { ctx.drawImage(ctx.canvas, 0, 0, w, h, 0, 0, sw, sh); } catch { return { motion: 0.5, frame: prev || new ImageData(sw, sh) }; }
  const cur = ctx.getImageData(0, 0, sw, sh);
  if (!prev || prev.width !== sw || prev.height !== sh) return { motion: 0.5, frame: cur };
  let sumAbsDiff = 0;
  for (let i = 0; i < sw * sh; i++) {
    const a = 0.299 * prev.data[i * 4] + 0.587 * prev.data[i * 4 + 1] + 0.114 * prev.data[i * 4 + 2];
    const b = 0.299 * cur.data[i * 4] + 0.587 * cur.data[i * 4 + 1] + 0.114 * cur.data[i * 4 + 2];
    sumAbsDiff += Math.abs(a - b);
  }
  const meanDiff = sumAbsDiff / (sw * sh);   // 0..255
  // 0 mean diff → motion 1; ~25+ mean diff → motion 0 (lots of movement).
  return { motion: Math.max(0, Math.min(1, 1 - meanDiff / 25)), frame: cur };
}
