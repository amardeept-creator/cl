import 'server-only';
import { readFile } from 'fs/promises';
import path from 'path';
import { processGlb } from '../glb';
import { putObject } from '../storage';
import { shortId } from '../ids';
import { sql } from '../db';
import type { ReconstructionProvider, SubmitInput, SubmitResult, PollResult, FrameInput } from './types';

/**
 * MOCK RECONSTRUCTION PROVIDER — clearly labelled prototype.
 *
 * This provider does NOT actually do photogrammetry. It picks an existing
 * SKINIFY seed GLB based on the product category and returns it as the
 * "reconstructed" model. This lets the entire scanning UI, processing
 * pipeline and AR viewer be developed and demoed end-to-end without
 * third-party API keys.
 *
 * To swap in a real provider:
 *   1. Implement `ReconstructionProvider` (see types.ts) in a new file,
 *      e.g. `tripo3d.ts`.
 *   2. Register it in `index.ts` (getProvider()).
 *   3. Set RECONSTRUCTION_PROVIDER env var.
 *
 * The mock always returns isMock=true so the UI can clearly label
 * results as a prototype to the seller.
 */

// Map category → seed model name. Each entry corresponds to a file in /public/seed/models.
const CATEGORY_SEED: Record<string, string> = {
  jewellery: 'ring-solitaire',
  watches: 'watch-meridian',
  eyewear: 'glasses-wayfarer',
  nails: 'ring-solitaire',
  beauty: 'ring-solitaire',
  fashion: 'hat-beanie',
  accessories: 'bag-tote',
  footwear: 'bag-tote',
  home: 'home-vase',
  more: 'home-vase',
};

// In-memory mock job store (a real provider stores state on its side).
interface MockJob {
  externalJobId: string;
  startedAt: number;
  coveragePct: number;
  scanQuality: 'unknown' | 'low' | 'medium' | 'high';
  categorySlug: string | null;
  productName: string;
  frames: FrameInput[];
  status: 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED';
  progress: number;
  modelUrl?: string;
  error?: string;
}
const JOBS = new Map<string, MockJob>();

const FIXED_DURATION_MS = 6000; // pretend reconstruction takes ~6 seconds

export const mockProvider: ReconstructionProvider = {
  name: 'mock',
  isMock: true,

  async submit(input: SubmitInput): Promise<SubmitResult> {
    const externalJobId = 'mock-' + shortId(12);
    JOBS.set(externalJobId, {
      externalJobId,
      startedAt: Date.now(),
      coveragePct: input.coveragePct,
      scanQuality: input.scanQuality,
      categorySlug: input.categorySlug,
      productName: input.productName,
      frames: input.frames,
      status: 'RUNNING',
      progress: 0,
    });
    return { externalJobId, status: 'RUNNING', etaSeconds: Math.round(FIXED_DURATION_MS / 1000) };
  },

  async poll(externalJobId: string): Promise<PollResult> {
    const job = JOBS.get(externalJobId);
    if (!job) return { status: 'FAILED', progress: 0, error: 'Mock job not found' };

    const elapsed = Date.now() - job.startedAt;
    const pct = Math.min(100, Math.round((elapsed / FIXED_DURATION_MS) * 100));

    // Coverage gate — never fake a successful reconstruction when the scan was poor.
    if (job.coveragePct < 35) {
      job.status = 'FAILED'; job.progress = 100; job.error = 'INSUFFICIENT_COVERAGE';
      return { status: 'FAILED', progress: 100, error: 'Insufficient coverage. Capture more of the product from different angles.' };
    }

    if (pct >= 100) {
      try {
        const modelUrl = await materializeMockModel(job);
        job.status = 'SUCCEEDED'; job.progress = 100; job.modelUrl = modelUrl;
        return { status: 'SUCCEEDED', progress: 100, modelUrl, modelFormat: 'glb' };
      } catch (e) {
        job.status = 'FAILED'; job.progress = 100; job.error = (e as Error).message;
        return { status: 'FAILED', progress: 100, error: (e as Error).message };
      }
    }

    job.progress = pct;
    return { status: 'RUNNING', progress: pct };
  },

  async cancel(externalJobId: string) {
    const job = JOBS.get(externalJobId);
    if (job) { job.status = 'FAILED'; job.error = 'Cancelled'; }
  },
};

/** Load the seed GLB for the job's category, run it through the standard GLB pipeline
 *  (validate + dedup + prune + meshopt) so the result is a real, AR-ready GLB —
 *  identical in shape to what a real reconstruction provider would produce. */
async function materializeMockModel(job: MockJob): Promise<string> {
  const seedName = CATEGORY_SEED[job.categorySlug || ''] || 'home-vase';
  const seedPath = path.join(process.cwd(), 'public', 'seed', 'models', `${seedName}.glb`);
  const input = await readFile(seedPath);
  const { report, output } = await processGlb(new Uint8Array(input));
  if (!report.ok) throw new Error(report.error || 'Mock seed GLB failed validation');

  // Store the optimized GLB as a proper Skinify ar_asset. Seller = Skinify base
  // (seller_id null + is_template=true) since the mock provider can't truly "own" assets.
  const key = `scans/mock/${job.externalJobId}/${shortId(6)}.glb`;
  const { url } = await putObject(key, output, 'model/gltf-binary');

  const meta = {
    bbox: report.bbox, triangles: report.triangles, meshes: report.meshes,
    materials: report.materials, textures: report.textures,
    maxTextureSize: report.maxTextureSize, extensions: report.extensions,
    warnings: [...report.warnings, 'PROTOTYPE: this model was produced by the mock reconstruction provider.'],
    optimized: report.optimized,
    scan: { sessionId: job.frames[0]?.url?.includes('/scans/') ? 'mock' : 'mock', coverage: job.coveragePct, scanQuality: job.scanQuality, frameCount: job.frames.length, mock: true },
  };

  const [row] = await sql`insert into ar_assets (seller_id, kind, storage_key, url, original_filename, mime, bytes, original_bytes, meta, is_template, template_name, status)
    values (${null}, 'model', ${key}, ${url}, ${`scan-${job.productName || 'product'}.glb`}, 'model/gltf-binary', ${output.length}, ${input.length}, ${sql.json(meta as never)}, true, ${`Scan prototype · ${job.productName || 'product'}`}, 'ready')
    returning id, url`;
  return row.url;
}
