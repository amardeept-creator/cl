import 'server-only';

/**
 * Reconstruction provider abstraction.
 *
 * Skinify never hard-codes itself to one photogrammetry / 3D-reconstruction vendor.
 * Each provider implements this interface. The active provider is selected by env:
 *
 *   RECONSTRUCTION_PROVIDER = 'mock' | 'tripo3d' | 'luma' | 'meshy' | 'nvidia_omniverse' | 'custom'
 *
 * Provider API keys (RECONSTRUCTION_API_KEY / RECONSTRUCTION_API_URL) live server-side
 * and are NEVER exposed to the browser.
 *
 * Pipeline:
 *   scanSession
 *     → reconstructionJob  (provider.submit)
 *     → reconstructedModel (provider.poll until status = SUCCEEDED)
 *     → optimizedModel     (server-side glTF-Transform dedup/prune/meshopt — lib/server/glb.ts)
 *     → arAsset            (ar_assets row, ready for AR)
 */

export type ProviderName = 'mock' | 'tripo3d' | 'luma' | 'meshy' | 'nvidia_omniverse' | 'custom';

export type JobStatus = 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export interface FrameInput {
  url: string;          // Skinify-hosted URL the provider can fetch
  sequence: number;
  viewpoint: { yawDeg: number; pitchDeg: number; sharpness?: number; brightness?: number; trackerConfidence?: number };
  isKeyframe: boolean;
}

export interface SubmitInput {
  jobId: string;        // Skinify reconstruction_jobs.id (UUID)
  sessionId: string;    // Skinify scan_sessions.id (UUID)
  categorySlug: string | null;
  productName: string;
  frames: FrameInput[];
  coveragePct: number;
  scanQuality: 'unknown' | 'low' | 'medium' | 'high';
}

export interface SubmitResult {
  externalJobId: string;
  status: JobStatus;
  /** Estimated seconds before the model is ready (best-effort). */
  etaSeconds?: number;
}

export interface PollResult {
  status: JobStatus;
  progress: number;        // 0..100
  /** Set when status = SUCCEEDED. Must be reachable by Skinify's server (signed URL ok). */
  modelUrl?: string;
  /** Optional format hint, e.g. 'glb' | 'gltf' | 'usdz' | 'obj+mtl' | 'ply'. */
  modelFormat?: string;
  error?: string;
}

export interface ReconstructionProvider {
  readonly name: ProviderName;
  readonly isMock: boolean;
  /** Submit a reconstruction job to the provider. Never throws on provider-side failure — returns FAILED. */
  submit(input: SubmitInput): Promise<SubmitResult>;
  /** Poll an existing provider job. Idempotent. */
  poll(externalJobId: string): Promise<PollResult>;
  /** Cancel a running provider job if supported. */
  cancel?(externalJobId: string): Promise<void>;
}
