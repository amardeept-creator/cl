import 'server-only';
import { promises as fs } from 'fs';
import path from 'path';

/**
 * Object storage abstraction.
 *  - production (Vercel): Vercel Blob (BLOB_READ_WRITE_TOKEN) → public CDN URLs, immutable caching
 *  - production (Cloudflare Pages): Cloudflare R2 (R2_ACCOUNT_ID + R2_ACCESS_KEY_ID + R2_SECRET_ACCESS_KEY + R2_BUCKET + NEXT_PUBLIC_R2_PUBLIC_URL)
 *    Uses the S3-compatible API over HTTPS — no Node fs, no TCP. Works on Workers with nodejs_compat.
 *  - local dev:  .data/uploads served by /api/files/[...key]
 * Large 3D assets never live in the application bundle.
 */
export type Driver = 'blob' | 'r2' | 'local' | 'none';

export function storageDriver(): Driver {
  if (process.env.BLOB_READ_WRITE_TOKEN) return 'blob';
  if (process.env.R2_BUCKET && process.env.R2_ACCESS_KEY_ID && process.env.R2_SECRET_ACCESS_KEY) return 'r2';
  if (process.env.CF_PAGES) return 'none'; // serverless build is read-only; uploads need Blob/R2
  if (process.env.VERCEL) return 'none';   // serverless FS is read-only: uploads require Blob
  return 'local';
}

const LOCAL_ROOT = path.join(process.cwd(), '.data', 'uploads');

export async function putObject(key: string, body: Buffer | Uint8Array, contentType: string) {
  const d = storageDriver();
  if (d === 'blob') {
    const { put } = await import('@vercel/blob');
    const r = await put(key, Buffer.from(body), { access: 'public', contentType, addRandomSuffix: false, allowOverwrite: true, cacheControlMaxAge: 31536000 });
    return { key, url: r.url };
  }
  if (d === 'r2') {
    return putR2Object(key, body, contentType);
  }
  if (d === 'local') {
    const p = path.join(LOCAL_ROOT, key); await fs.mkdir(path.dirname(p), { recursive: true }); await fs.writeFile(p, body);
    return { key, url: `/api/files/${key}` };
  }
  throw new Error('STORAGE_NOT_CONFIGURED');
}

/** Upload to R2 via the S3-compatible API (HTTPS — works on Cloudflare Workers edge runtime). */
async function putR2Object(key: string, body: Buffer | Uint8Array, contentType: string) {
  const accountId = process.env.R2_ACCOUNT_ID!;
  const bucket = process.env.R2_BUCKET!;
  const accessKeyId = process.env.R2_ACCESS_KEY_ID!;
  const secretAccessKey = process.env.R2_SECRET_ACCESS_KEY!;
  const publicBase = process.env.NEXT_PUBLIC_R2_PUBLIC_URL!; // e.g. https://cdn.example.com
  const host = `${accountId}.r2.cloudflarestorage.com`;
  const path = `/${bucket}/${key}`;
  const endpoint = `https://${host}${path}`;
  const bodyBuf = Buffer.isBuffer(body) ? body : Buffer.from(body);
  const bodyBytes = new Uint8Array(bodyBuf.buffer, bodyBuf.byteOffset, bodyBuf.byteLength);

  // Sign the request using AWS SigV4 (R2 is S3-compatible).
  const signedHeaders = await signR2Request({
    method: 'PUT', host, path,
    headers: {
      host,
      'content-type': contentType,
      'content-length': String(bodyBytes.byteLength),
      'cache-control': 'public, max-age=31536000, immutable',
    },
    body: bodyBytes,
    accessKeyId, secretAccessKey,
  });

  const r = await fetch(endpoint, {
    method: 'PUT',
    body: bodyBytes as BodyInit,
    headers: signedHeaders,
  });
  if (!r.ok) {
    const text = await r.text().catch(() => '');
    throw new Error(`R2 PUT failed (${r.status}): ${text.slice(0, 200)}`);
  }
  return { key, url: `${publicBase.replace(/\/$/, '')}/${key}` };
}

/** AWS SigV4 signing for R2. Uses @aws-sdk/signature-v4 if installed, falls back to a
 *  clear error message telling the deployer to install it. */
async function signR2Request(opts: {
  method: string; host: string; path: string;
  headers: Record<string, string>;
  body: Uint8Array;
  accessKeyId: string; secretAccessKey: string;
}): Promise<Record<string, string>> {
  let sdk: { SignatureV4: new (opts: unknown) => { sign: (req: unknown) => Promise<{ headers: Record<string, string> }> }; HttpRequest: new (opts: unknown) => unknown; Sha256: new (data?: unknown) => unknown } | null = null;
  try {
    // The AWS SDK packages are optional — only installed when the deployer chooses R2.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sig: any = await import(/* @vite-ignore */ '@aws-sdk/signature-v4').catch(() => null as any);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const http: any = await import(/* @vite-ignore */ '@aws-sdk/protocol-http').catch(() => null as any);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const crt: any = await import(/* @vite-ignore */ '@aws-crypto/sha256-js').catch(() => null as any);
    if (sig?.SignatureV4 && http?.HttpRequest && crt?.Sha256) {
      sdk = { SignatureV4: sig.SignatureV4, HttpRequest: http.HttpRequest, Sha256: crt.Sha256 };
    }
  } catch { /* SDK not installed — fall through to clear error below */ }

  if (!sdk) {
    throw new Error('R2 storage requires @aws-sdk/signature-v4 + @aws-sdk/protocol-http + @aws-crypto/sha256-js. Install them with: npm i @aws-sdk/signature-v4 @aws-sdk/protocol-http @aws-crypto/sha256-js');
  }

  const req = new sdk.HttpRequest({
    method: opts.method, protocol: 'https:', hostname: opts.host, path: opts.path,
    headers: opts.headers, body: opts.body,
  });
  const signer = new sdk.SignatureV4({
    credentials: { accessKeyId: opts.accessKeyId, secretAccessKey: opts.secretAccessKey },
    region: 'auto', service: 's3', sha256: sdk.Sha256,
  });
  const signed = await signer.sign(req);
  return signed.headers;
}

export async function readLocal(key: string) {
  const p = path.normalize(path.join(LOCAL_ROOT, key));
  if (!p.startsWith(LOCAL_ROOT)) throw new Error('bad key');
  return fs.readFile(p);
}

export async function deleteObject(url: string) {
  try {
    if (storageDriver() === 'blob' && /blob\.vercel-storage\.com/.test(url)) { const { del } = await import('@vercel/blob'); await del(url); }
    // R2 deletion is intentionally a no-op here — R2 objects are immutable per-scan and cleaned up by lifecycle rules.
  } catch (e) { console.warn('[storage] delete failed', e); }
}

export async function fetchObject(url: string, maxBytes: number) {
  const r = await fetch(url); if (!r.ok) throw new Error('fetch failed');
  const len = Number(r.headers.get('content-length') || 0); if (len > maxBytes) throw new Error('too large');
  const b = Buffer.from(await r.arrayBuffer()); if (b.length > maxBytes) throw new Error('too large');
  return b;
}
