/** @type {import('next').NextConfig} */
const isCloudflare = process.env.CLOUDFLARE === '1' || !!process.env.CF_PAGES;
const blobHost = 'https://*.public.blob.vercel-storage.com';
const r2Host = process.env.NEXT_PUBLIC_R2_PUBLIC_URL ? new URL(process.env.NEXT_PUBLIC_R2_PUBLIC_URL).origin : null;
const modelViewerHost = 'https://unpkg.com';
const imgSources = ['self', 'data:', 'blob:', blobHost];
if (r2Host) imgSources.push(r2Host);
const connectSources = ['self', 'blob:', 'data:', blobHost, modelViewerHost, 'https://storage.googleapis.com', 'https://www.gstatic.com', 'https://vercel.com', 'https://*.vercel-storage.com'];
if (r2Host) connectSources.push(r2Host);

const csp = (frameAncestors) => [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' blob:${process.env.NODE_ENV === 'production' ? '' : " 'unsafe-eval'"} ${modelViewerHost}`,
  "style-src 'self' 'unsafe-inline' https://api.fontshare.com",
  "font-src 'self' https://cdn.fontshare.com data:",
  `img-src ${imgSources.join(' ')}`,
  "media-src 'self' blob: data:",
  `connect-src ${connectSources.join(' ')}`,
  "worker-src 'self' blob:",
  `frame-ancestors ${frameAncestors}`,
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
].join('; ');

const security = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
];

export default {
  reactStrictMode: true,
  poweredByHeader: false,
  serverExternalPackages: ['@gltf-transform/core', '@gltf-transform/functions', '@gltf-transform/extensions', 'meshoptimizer'],
  // The Cloudflare adapter (@cloudflare/next-on-pages) sets CF_PAGES at build time.
  // It builds everything as Edge runtime; routes that use Node-only APIs (fs,
  // Buffer, TCP sockets) need nodejs_compat — enabled via wrangler.jsonc.
  async headers() {
    return [
      { source: '/((?!embed/).*)', headers: [...security, { key: 'Content-Security-Policy', value: csp("'self'") }, { key: 'Permissions-Policy', value: 'camera=(self), microphone=(), geolocation=(), xr-spatial-tracking=(self)' }] },
      // Embeds may be framed by any seller website; camera must be delegated with allow="camera".
      { source: '/embed/:path*', headers: [...security, { key: 'Content-Security-Policy', value: csp('*') }, { key: 'Permissions-Policy', value: 'camera=*, microphone=(), geolocation=()' }] },
      { source: '/seed/:path*', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
      { source: '/mediapipe/:path*', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
      { source: '/sdk/:path*', headers: [{ key: 'Cache-Control', value: 'public, max-age=300' }, { key: 'Access-Control-Allow-Origin', value: '*' }] },
    ];
  },
  async redirects() { return [{ source: '/dashboard/create', destination: '/dashboard/skinners/new', permanent: false }]; },
};
