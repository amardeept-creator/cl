import { defineCloudflareConfig } from '@opennextjs/cloudflare';

/**
 * OpenNext for Cloudflare Workers configuration.
 *
 * This file is read by `@opennextjs/cloudflare` at build time to know how to
 * convert the Next.js build output into a Cloudflare Workers-compatible bundle.
 *
 * Docs: https://opennext.js.org/cloudflare
 */
export default defineCloudflareConfig();
