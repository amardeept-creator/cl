/**
 * Optional module declarations for the AWS SDK packages used by R2 storage.
 * These packages are NOT installed by default — they're only needed when the
 * deployer chooses Cloudflare R2 as the object storage backend.
 *
 * If the packages are installed (npm i @aws-sdk/signature-v4 @aws-sdk/protocol-http @aws-crypto/sha256-js),
 * the real type definitions take precedence over these stubs.
 *
 * If they aren't installed, these stubs let TypeScript compile cleanly and
 * lib/server/storage.ts throws a clear runtime error directing the deployer
 * to install them.
 */
declare module '@aws-sdk/signature-v4' {
  export class SignatureV4 {
    constructor(opts: unknown);
    sign(req: unknown): Promise<{ headers: Record<string, string> }>;
  }
}
declare module '@aws-sdk/protocol-http' {
  export class HttpRequest {
    constructor(opts: unknown);
  }
}
declare module '@aws-crypto/sha256-js' {
  export class Sha256 {
    constructor(data?: unknown);
    digest(): Promise<Uint8Array>;
  }
}
