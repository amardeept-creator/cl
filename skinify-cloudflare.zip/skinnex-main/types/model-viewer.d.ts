import type { DetailedHTMLProps, HTMLAttributes } from 'react';

/**
 * Type declarations for the Google <model-viewer> web component.
 * The actual component is loaded at runtime from https://unpkg.com/@google/model-viewer
 * (see components/scan/ModelViewer3D.tsx). These declarations let TypeScript
 * accept <model-viewer ... /> as a JSX intrinsic element.
 *
 * React 19 puts the JSX namespace under `React.JSX` rather than the global `JSX`,
 * so we declare both for compatibility.
 *
 * Only the attributes Skinify actually sets are typed. For the full attribute
 * reference see https://modelviewer.dev/docs/index.html
 */
type ModelViewerAttributes = DetailedHTMLProps<HTMLAttributes<HTMLElement> & {
  // Core
  src?: string;
  poster?: string;
  alt?: string;
  // AR
  ar?: boolean;
  'ar-modes'?: string;
  'ar-scale'?: 'fixed' | 'auto';
  'ios-src'?: string;
  'quick-look-browsers'?: string;
  'xr-environment'?: string;
  // Camera
  'camera-controls'?: boolean;
  'camera-orbit'?: string;
  'camera-target'?: string;
  'field-of-view'?: string;
  'min-camera-orbit'?: string;
  'max-camera-orbit'?: string;
  'min-field-of-view'?: string;
  'max-field-of-view'?: string;
  // Auto-rotate
  'auto-rotate'?: boolean;
  'auto-rotate-delay'?: number;
  'rotation-per-second'?: string;
  // Lighting / environment
  'environment-image'?: string;
  'skybox-image'?: string;
  exposure?: string;
  'shadow-intensity'?: string | number;
  'shadow-softness'?: string | number;
  // Interaction prompt
  'interaction-prompt'?: 'auto' | 'when-focused' | 'none';
  'interaction-prompt-style'?: 'wiggle' | 'basic';
  'interaction-prompt-threshold'?: string;
  // Animation
  animationName?: string;
  'animation-crossfade-duration'?: string;
  autoplay?: boolean;
  // Tone mapping
  'tone-mapping'?: 'aces' | 'neutral' | 'agx' | 'none';
  // Misc
  'reveal'?: 'auto' | 'interaction';
  'preload'?: boolean;
  'poster-color'?: string;
  'progress-bar-color'?: string;
  'progress-mask'?: string;
  // Event handlers — model-viewer dispatches CustomEvents; we listen via addEventListener.
  onLoad?: unknown;
  onError?: unknown;
}, HTMLElement>;

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': ModelViewerAttributes;
    }
  }
  namespace React {
    namespace JSX {
      interface IntrinsicElements {
        'model-viewer': ModelViewerAttributes;
      }
    }
  }
}

export {};
